import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput } from 'react-native';
import Constants from 'expo-constants';
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';

// Importar a imagem
import googleLogo from './google-logo.png';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <MaterialIcons name="camera" size={24} color="black" style={styles.icon} />
        <MaterialCommunityIcons name="dots-vertical" size={24} color="black" style={styles.icon} />
      </View>
      <View style={styles.contentContainer}>
        <Image source={googleLogo} style={styles.logo} />
        <TextInput
          style={styles.input}
          placeholder="Search or type URL"
          placeholderTextColor="#aaa"
        />
      </View>
      <Text style={styles.paragraph}>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start', // Ajustar para "flex-start"
    alignItems: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  contentContainer: {
    marginTop: 48, // Adicionar margem superior para mover a imagem e a barra de pesquisa para cima
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  logo: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
  },
  input: {
    marginTop: 16,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#aaa',
    width: '100%',
    fontSize: 16,
    color: '#333',
  },
  iconContainer: {
    flexDirection: 'row',
    position: 'absolute',
    top: 0,
    right: 0,
    padding: 16,
  },
  icon: {
    marginHorizontal: 8,
  },
});
